<?php
return <<<'JSON'
{
    "vendor": "Miller Media",
    "author": "Kevin Carwile",
    "name": "Users List",
    "namespace": "MillerMedia\\UsersList",
    "slug": "millermedia-userslist",
    "version": "0.0.2"
}
JSON;
