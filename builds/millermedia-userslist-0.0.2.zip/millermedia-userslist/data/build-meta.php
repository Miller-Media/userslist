<?php
return <<<'JSON'
{
    "framework_version": "2.0.5",
    "framework_bundled": true
}
JSON;
